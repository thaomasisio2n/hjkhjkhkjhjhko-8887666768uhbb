"""
Temp Mail API – generowanie tymczasowego emaila i pobieranie wiadomości (w tym kodów).
Dokumentacja: https://docs.temp-mail.io/docs/getting-started
"""

import os
import re
import time
from typing import List, Optional

import requests

# Ładowanie .env (jeśli jest python-dotenv)
try:
    from dotenv import load_dotenv
    load_dotenv()
except ImportError:
    pass

BASE_URL = "https://api.temp-mail.io/v1"


class TempMailClient:
    def __init__(self, api_key: Optional[str] = None):
        self.api_key = api_key or os.environ.get("TEMP_MAIL_API_KEY")
        if not self.api_key:
            raise ValueError(
                "Podaj API key: argument api_key lub zmienna TEMP_MAIL_API_KEY, "
                "albo utwórz plik .env z TEMP_MAIL_API_KEY=twój_klucz"
            )
        self.session = requests.Session()
        self.session.headers["X-API-Key"] = self.api_key
        self.email: Optional[str] = None
        self.ttl: Optional[int] = None

    def create_email(self) -> dict:
        """Tworzy nowy tymczasowy adres email."""
        r = self.session.post(f"{BASE_URL}/emails")
        r.raise_for_status()
        data = r.json()
        self.email = data["email"]
        self.ttl = data.get("ttl", 86400)
        return data

    def get_messages(self, email: Optional[str] = None) -> List[dict]:
        """Pobiera listę wiadomości dla podanego (lub ostatnio utworzonego) emaila."""
        addr = email or self.email
        if not addr:
            raise ValueError("Brak adresu email – najpierw wywołaj create_email()")
        r = self.session.get(f"{BASE_URL}/emails/{addr}/messages")
        r.raise_for_status()
        return r.json().get("messages", [])

    def get_message(self, message_id: str) -> dict:
        """Pobiera pełną treść konkretnej wiadomości."""
        r = self.session.get(f"{BASE_URL}/messages/{message_id}")
        r.raise_for_status()
        return r.json()

    def get_message_source(self, message_id: str) -> str:
        """Pobiera surowy kod źródłowy wiadomości (raw)."""
        r = self.session.get(f"{BASE_URL}/messages/{message_id}/source")
        r.raise_for_status()
        return r.text

    def delete_message(self, message_id: str) -> None:
        """Usuwa wybraną wiadomość."""
        r = self.session.delete(f"{BASE_URL}/messages/{message_id}")
        r.raise_for_status()

    def delete_email(self, email: Optional[str] = None) -> None:
        """Usuwa tymczasowy email i wszystkie wiadomości."""
        addr = email or self.email
        if not addr:
            raise ValueError("Brak adresu email")
        r = self.session.delete(f"{BASE_URL}/emails/{addr}")
        r.raise_for_status()

    def wait_for_message(
        self,
        timeout: int = 120,
        interval: int = 5,
        email: Optional[str] = None,
    ) -> List[dict]:
        """
        Czeka na pojawienie się co najmniej jednej wiadomości (np. z kodem).
        Zwraca listę wiadomości po upływie timeout lub gdy coś przyjdzie.
        """
        start = time.time()
        while time.time() - start < timeout:
            messages = self.get_messages(email)
            if messages:
                return messages
            time.sleep(interval)
        return []


def extract_codes(text: str) -> List[str]:
    """
    Wyciąga typowe kody weryfikacyjne z treści (np. 4–8 cyfr, często w nawiasach).
    """
    if not text:
        return []
    # 4–8 cyfr (np. 123456, 1234)
    patterns = [
        r"\b(\d{6})\b",   # 6 cyfr
        r"\b(\d{4})\b",   # 4 cyfr
        r"\b(\d{8})\b",   # 8 cyfr
        r"code[:\s]+(\d{4,8})",
        r"kod[:\s]+(\d{4,8})",
        r"verification[:\s]+(\d{4,8})",
        r"(\d{4,8})",
    ]
    found = set()
    for pat in patterns:
        for m in re.finditer(pat, text, re.IGNORECASE):
            found.add(m.group(1))
    return list(found)


def main():
    api_key = os.environ.get("TEMP_MAIL_API_KEY")
    if not api_key:
        print("Ustaw zmienną TEMP_MAIL_API_KEY lub podaj klucz w kodzie.")
        return

    client = TempMailClient(api_key=api_key)

    # 1. Generowanie emaila
    data = client.create_email()
    print("Utworzono email:", data["email"])
    print("TTL (sekundy):", data.get("ttl", "—"))

    # 2. Lista wiadomości (na start pusta)
    messages = client.get_messages()
    print("Liczba wiadomości:", len(messages))

    # 3. Przykład: czekanie na wiadomość i pobranie treści + kodów
    print("\nCzekam do 60 s na pierwszą wiadomość (możesz coś wysłać na ten adres)...")
    received = client.wait_for_message(timeout=60, interval=3)
    if not received:
        print("Brak wiadomości w czasie oczekiwania.")
        return

    for msg in received:
        print("\n--- Wiadomość ---")
        print("Od:", msg.get("from"))
        print("Temat:", msg.get("subject"))
        print("ID:", msg.get("id"))
        full = client.get_message(msg["id"])
        body = full.get("body_text") or full.get("body_html") or ""
        print("Fragment treści:", (body[:300] + "…") if len(body) > 300 else body)
        codes = extract_codes(body)
        if codes:
            print("Wykryte kody:", codes)

    # Opcjonalnie: pobranie surowego źródła ostatniej wiadomości
    if received:
        msg_id = received[0]["id"]
        source = client.get_message_source(msg_id)
        print("\nDługość źródła (source) w znakach:", len(source))


if __name__ == "__main__":
    main()
