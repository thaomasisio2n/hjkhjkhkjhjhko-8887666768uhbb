import re
import time

from config import PROXY_HOST, PROXY_PASSWORD, PROXY_PORT, PROXY_USER
from smailpro_client import SmailProClient, SmailProError

OUTLOOK_DOMAINS = ("@outlook.com", "@hotmail.com", "@live.com", "@msn.com")

# Sesja SmailPro wymaga email + timestamp z momentu generowania.
_EMAIL_SESSIONS = {}
_SEEN_MESSAGE_IDS = {}
_CLIENT = None


def _build_proxies():
    if not (PROXY_HOST and PROXY_PORT and PROXY_USER and PROXY_PASSWORD):
        return None
    proxy_url = f"http://{PROXY_USER}:{PROXY_PASSWORD}@{PROXY_HOST}:{PROXY_PORT}"
    return {"http": proxy_url, "https": proxy_url}


def _get_client() -> SmailProClient:
    global _CLIENT
    if _CLIENT is None:
        _CLIENT = SmailProClient(proxies=_build_proxies())
    return _CLIENT


def _resolve_session(email_id: str):
    if email_id in _EMAIL_SESSIONS:
        return _EMAIL_SESSIONS[email_id]
    if "|" in email_id:
        email, ts = email_id.split("|", 1)
        try:
            return _EMAIL_SESSIONS.get(email_id) or {
                "email": email,
                "timestamp": int(ts),
                "provider": "outlook",
            }
        except ValueError:
            pass
    return None


def _is_outlook_email(email: str) -> bool:
    lowered = email.lower()
    return any(lowered.endswith(domain) for domain in OUTLOOK_DOMAINS)


def _register_session(email: str, timestamp: int, provider: str):
    session_id = f"{email}|{timestamp}"
    session = {"email": email, "timestamp": int(timestamp), "provider": provider}
    _EMAIL_SESSIONS[session_id] = session
    _EMAIL_SESSIONS[email] = session
    _SEEN_MESSAGE_IDS[session_id] = set()
    return session


def _create_outlook_session(client, outlook_type: str):
    data = client.random_outlook(outlook_type=outlook_type)
    email = (data.get("email") or "").strip()
    timestamp = data.get("timestamp")
    if not email or timestamp is None:
        raise SmailProError("Brak email lub timestamp w odpowiedzi SmailPro Outlook")
    if not _is_outlook_email(email):
        raise SmailProError(f"Otrzymano adres spoza Outlook/Microsoft: {email}")

    _register_session(email, int(timestamp), "outlook")
    return data, email, int(timestamp)


def get_email(mailDomain):
    """
    Tworzy tymczasowy Outlook/Hotmail przez SmailPro.
    Najpierw real; przy błędzie jedna próba z alias.
    Zwraca: {"email": "...", "id": "email|timestamp"}.
    """
    _ = mailDomain
    client = _get_client()
    attempts = [
        ("real", "Real Outlook"),
        ("alias", "Alias Outlook (fallback)"),
    ]
    last_error = None

    for index, (outlook_type, label) in enumerate(attempts):
        try:
            data, email, timestamp = _create_outlook_session(client, outlook_type)
            print(f"📧 SmailPro {label}: {email} (timestamp={timestamp})")
            if data.get("remainingCredit"):
                print(f"💳 SmailPro credits left: {data['remainingCredit']}")
            return {"email": email, "id": f"{email}|{timestamp}"}
        except (SmailProError, Exception) as e:
            last_error = e
            print(f"⚠️ SmailPro {label} failed: {e}")
            if index == 0:
                print("🔄 Próbuję fallback alias (1x)...")
                continue
            break

    print(f"Error creating email (SmailPro Outlook): {last_error}")
    return {"email": "error", "id": "error"}


def _fetch_inbox(client, session):
    email = session["email"]
    timestamp = session["timestamp"]
    if session.get("provider") == "outlook":
        return client.outlook_inbox(email, timestamp)
    return client.gmail_inbox(email, timestamp)


def _fetch_message_body(client, session, mid: str):
    email = session["email"]
    if session.get("provider") == "outlook":
        return client.outlook_message(email, mid)
    return client.gmail_message(email, mid)


def check_email_otp(emailID):
    """
    Minimalna liczba requestów SmailPro:
    - 1x inbox poll na iterację,
    - message body tylko dla nowych wiadomości (mid), każda max 1 raz.
    """
    try:
        session = _resolve_session(emailID)
        if not session:
            print(f"Brak sesji SmailPro dla emailID={emailID}")
            return "NO_CODE"

        client = _get_client()
        messages = _fetch_inbox(client, session)
        if not messages:
            return "NO_CODE"

        seen = _SEEN_MESSAGE_IDS.setdefault(emailID, set())
        new_msgs = [m for m in messages if m.get("mid") and m.get("mid") not in seen]
        new_msgs.sort(key=lambda m: m.get("textDate", ""), reverse=True)

        for msg in new_msgs:
            mid = msg.get("mid")
            if not mid:
                continue
            seen.add(mid)

            list_text = " ".join([
                msg.get("textSubject", "") or "",
                msg.get("textFrom", "") or "",
            ])
            link = find_link_in_text(list_text)
            if link:
                return link

            body = _fetch_message_body(client, session, mid)
            link = find_link_in_text(body)
            if link:
                return link

        return "NO_CODE"
    except SmailProError as e:
        print(f"Error checking OTP (SmailPro): {e}")
        return "NO_CODE"
    except Exception as e:
        print(f"Error checking OTP: {e}")
        return "NO_CODE"


def find_link_in_text(text):
    pattern = r'https://onlyfans\.com/action/email/registration/[A-Za-z0-9_]+[?=][A-Za-z0-9=&]+'
    link = re.search(pattern, text)
    if link:
        return link.group(0)
    return None


def blocking(emailID, max_wait_time=120):
    start_time = time.time()
    interval = 8
    while time.time() - start_time < max_wait_time:
        try:
            code = check_email_otp(emailID)
            if code and code != "NO_CODE":
                print(f"✅ Odebrany kod: {code}")
                return code
        except Exception as error:
            print(f"⚠️ Błąd pobierania kodu: {error}")
        time.sleep(interval)
        interval = min(20, interval + 2)
    print("❌ Nie udało się pobrać kodu w wyznaczonym czasie.")
    raise Exception("❌ Nie udało się pobrać kodu w wyznaczonym czasie.")
