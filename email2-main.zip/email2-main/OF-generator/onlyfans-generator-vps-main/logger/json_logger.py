
# import os
# import json
# from datetime import datetime

# LOG_FILE = "log.json"

# def addBot(profile_data):
#     ftl_key = profile_data["ftl"]  # Grupa, np. jakiś projekt

#     # Lista botów dla tej instancji
#     bot_instances = [
#         {
#             "timestamp": datetime.utcnow().isoformat(),
#             "email": profile_data["email"],
#             "password": profile_data["password"],
#             "name": profile_data["name"],
#             "username": profile_data["username"],
#             "biogram": profile_data["biogram"]
#         }
#     ]

#     # Jeśli plik istnieje, wczytaj dane
#     if os.path.exists(LOG_FILE):
#         with open(LOG_FILE, "r+", encoding="utf-8") as f:
#             try:
#                 logs = json.load(f)
#             except json.JSONDecodeError:
#                 logs = {}
#     else:
#         logs = {}

#     # Dodaj dane do odpowiedniej grupy FTL
#     if ftl_key not in logs:
#         logs[ftl_key] = []

#     logs[ftl_key].extend(bot_instances)

#     # Zapisz do pliku
#     with open(LOG_FILE, "w", encoding="utf-8") as f:
#         json.dump(logs, f, indent=2, ensure_ascii=False)

#     print(f"📝 Zapisano {len(bot_instances)} botów pod ftl: {ftl_key}")
