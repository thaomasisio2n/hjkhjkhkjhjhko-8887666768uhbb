from faker import Faker

fake = Faker('en_US')

def generate_address_for_state(target_state):
    while True:
        address = {
            "street": fake.street_address(),
            "city": fake.city(),
            "state": fake.state_abbr(),
            "zip": fake.zipcode()
        }
        if address["state"] == target_state:
            return address

# przykład
addr = generate_address_for_state("TX")  # Texas
print(addr)
