from datetime import datetime, timedelta
from config import PROXY_HOST, PROXY_PORT

class ProxyErrorTracker:
    def __init__(self):
        self.error_history = {}
        self.notification_cooldown = timedelta(minutes=30)  # Don't send notifications more than once every 30 minutes
        self.consecutive_failures = 0  # Track consecutive profile failures
        self.min_failures_for_notification = 3  # Only notify after 3 consecutive failures
        self.last_error_message_id = None  # Track the last error message sent
    
    def get_proxy_id(self):
        """Get a unique identifier for the current proxy"""
        return f"{PROXY_HOST}:{PROXY_PORT}"
    
    def should_send_notification(self, error_type):
        """
        Check if we should send a notification for this error type
        
        Args:
            error_type (str): Type of error (e.g., 'authentication', 'connection', 'timeout')
            
        Returns:
            dict: {'should_send': bool, 'first_occurred': str, 'error_count': int}
        """
        proxy_id = self.get_proxy_id()
        error_key = f"{proxy_id}_{error_type}"
        
        now = datetime.now()
        
        if error_key not in self.error_history:
            # First time this error occurred
            self.error_history[error_key] = {
                'first_occurred': now,
                'last_notification': now,
                'error_count': 1
            }
            return {
                'should_send': True,
                'first_occurred': now.strftime("%Y-%m-%d %H:%M:%S"),
                'error_count': 1
            }
        
        error_info = self.error_history[error_key]
        error_info['error_count'] += 1
        
        # Check if enough time has passed since last notification
        time_since_last = now - error_info['last_notification']
        
        if time_since_last >= self.notification_cooldown:
            error_info['last_notification'] = now
            return {
                'should_send': True,
                'first_occurred': error_info['first_occurred'].strftime("%Y-%m-%d %H:%M:%S"),
                'error_count': error_info['error_count']
            }
        
        return {
            'should_send': False,
            'first_occurred': error_info['first_occurred'].strftime("%Y-%m-%d %H:%M:%S"),
            'error_count': error_info['error_count']
        }
    
    def get_error_summary(self, error_type):
        """Get a summary of the error for notification"""
        proxy_id = self.get_proxy_id()
        error_key = f"{proxy_id}_{error_type}"
        
        if error_key in self.error_history:
            error_info = self.error_history[error_key]
            first_time = error_info['first_occurred'].strftime("%H:%M")
            count = error_info['error_count']
            
            if count == 1:
                return f"Proxy {proxy_id} has error first time at {first_time}"
            else:
                return f"Proxy {proxy_id} has error first time at {first_time} and till now it keeps showing constantly ({count} times)"
        
        return f"Proxy {proxy_id} has error"
    
    def clear_history(self):
        """Clear error history (useful for testing)"""
        self.error_history.clear()
    
    def record_profile_failure(self):
        """Record a profile creation failure"""
        self.consecutive_failures += 1
        print(f"📊 Consecutive profile failures: {self.consecutive_failures}")
    
    def record_profile_success(self, telegram_bot=None):
        """Record a successful profile creation and clear error message if needed"""
        if self.consecutive_failures > 0:
            print(f"✅ Profile creation successful! Clearing {self.consecutive_failures} consecutive failures")
            
            # If we had sent an error message, delete it
            if self.last_error_message_id:
                self.delete_error_message(telegram_bot)
            
            # Reset consecutive failures
            self.consecutive_failures = 0
    
    def should_send_proxy_notification(self):
        """Check if we should send proxy error notification based on consecutive failures"""
        return self.consecutive_failures >= self.min_failures_for_notification
    
    def set_error_message_id(self, message_id):
        """Store the ID of the error message sent"""
        self.last_error_message_id = message_id
    
    def delete_error_message(self, telegram_bot):
        """Delete the last error message if it exists"""
        if self.last_error_message_id and telegram_bot:
            print(f"🗑️  Deleting previous proxy error message (ID: {self.last_error_message_id})")
            success = telegram_bot.delete_message(self.last_error_message_id)
            if success:
                print("✅ Error message deleted successfully")
            else:
                print("❌ Failed to delete error message")
            self.last_error_message_id = None
