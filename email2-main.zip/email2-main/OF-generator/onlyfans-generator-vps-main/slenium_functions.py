import random
import time
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.common.by import By
from selenium.webdriver.support import expected_conditions as EC
from selenium.common.exceptions import ElementClickInterceptedException, TimeoutException


def random_wait(min_time=1, max_time=1.5):
  time.sleep(random.uniform(min_time, max_time))

def type_with_delay(element, text):
  for char in text:
    element.send_keys(char)



def wait_for_element(driver, selector, SearchType=By.CSS_SELECTOR, timeout=120):
  return WebDriverWait(driver, timeout).until(
      EC.presence_of_element_located((SearchType, selector))
  )


def wait_for_clickable(driver, selector, SearchType=By.CSS_SELECTOR, timeout=120):
  return WebDriverWait(driver, timeout).until(
      EC.element_to_be_clickable((SearchType, selector))
  )


def safe_click(driver, selector, SearchType=By.CSS_SELECTOR, timeout=30, retries=3):
  last_error = None
  for _ in range(retries):
    try:
      el = wait_for_clickable(driver, selector, SearchType=SearchType, timeout=timeout)
      driver.execute_script("arguments[0].scrollIntoView({block: 'center'});", el)
      random_wait(0.2, 0.6)
      el.click()
      return el
    except (ElementClickInterceptedException, TimeoutException) as e:
      last_error = e
      random_wait(0.4, 1.0)

  # Ostateczny fallback na JS click, gdy overlay nadal przeszkadza.
  el = wait_for_element(driver, selector, SearchType=SearchType, timeout=timeout)
  driver.execute_script("arguments[0].click();", el)
  return el
