from slenium_functions import random_wait, safe_click, type_with_delay, wait_for_element
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.common.by import By

def register(driver, profile_data):
        driver.get('https://www.onlyfans.com')
        safe_click(driver, 'button[at-attr="sign_up"]')
        name_el = wait_for_element(driver, "name", SearchType=By.NAME)
        type_with_delay(name_el, profile_data["name"])
        name_el.send_keys(Keys.TAB)
        
        # name_el.send_keys("1234567890")
        # name_el.send_keys(Keys.TAB)
        # name_el.send_keys("1234567890")

        email_el = wait_for_element(driver,"email",SearchType=By.NAME)

        type_with_delay(email_el, profile_data["email"])

        email_el.send_keys(Keys.TAB)
        random_wait()
        password_el = wait_for_element(driver,"password",SearchType=By.NAME)
        type_with_delay(password_el, profile_data["password"])
        random_wait()
        sub = wait_for_element(driver, 'button[at-attr="submit"]')
        safe_click(driver, 'button[at-attr="submit"]')
        print("clicked about to wait for 20 ")
        random_wait(20, 26)
        print("waited for 20")
        try:

                sub23 = wait_for_element(driver, 'button[at-attr="submit"]',timeout=2)
                print("found button")
                if sub23:

                        try:
                                safe_click(driver, 'button[at-attr="submit"]', timeout=3, retries=1)
                                print("clicked")
                        except:
                                print("error")
        except:
                print("no button")
        
        print("clickedPizda")

        # if sub.get_attribute("disabled"):
        #         raise Exception("diabled")
        #         print("disabled")

        
        # else:
        #         try:
        #                 sub.click()  
        #         except:
        #                 print("pornthu")