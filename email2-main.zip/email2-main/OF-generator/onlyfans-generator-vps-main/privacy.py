from slenium_functions import random_wait, wait_for_element

def changePrivacy(driver):
  driver.get("https://onlyfans.com/my/settings/security")
  random_wait(5, 6)
  wait_for_element(driver, 'label[at-attr="is_visible_online"]').click()




