import json
import random
from datetime import datetime

DATA_FILE = 'accounts.json'

def load_data():
    try:
        with open(DATA_FILE, 'r') as f:
            data = json.load(f)
    except FileNotFoundError:
        data = []
    return data

def save_data(data):
    with open(DATA_FILE, 'w') as f:
        json.dump(data, f, indent=4)

def reset_if_new_day(data):
    today = datetime.now().date().isoformat()
    for entry in data:
        if entry.get('last_updated') != today:
            entry['created_today'] = 0
            entry['last_updated'] = today
    return data

def get_random_available_link():
    data = load_data()
    data = reset_if_new_day(data)
    available_links = [entry for entry in data if entry['created_today'] < entry['daily_goal']]
    
    if not available_links:
        print("Wszystkie linki osiągnęły dzienny limit.")
        return None
    
    selected = random.choice(available_links)
    return selected['link']

def mark_link_as_used(link):
    data = load_data()
    data = reset_if_new_day(data)
    
    for entry in data:
        if entry['link'] == link:
            entry['created_today'] += 1
            print(f"Zapisano utworzenie konta dla {link}. Dziś: {entry['created_today']}/{entry['daily_goal']}")
            break
    
    save_data(data)

def add_link(link, daily_goal):
    data = load_data()
    if any(entry['link'] == link for entry in data):
        print("Link już istnieje.")
        return

    data.append({
        'link': link,
        'daily_goal': daily_goal,
        'created_today': 0,
        'last_updated': datetime.now().date().isoformat()
    })

    save_data(data)
    print(f"Dodano nowy link: {link}")
