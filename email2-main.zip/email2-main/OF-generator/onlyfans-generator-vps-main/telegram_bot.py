import requests
import json
from datetime import datetime

class TelegramBot:
    def __init__(self, bot_token, chat_id):
        """
        Initialize Telegram bot with bot token and chat ID
        
        Args:
            bot_token (str): Your Telegram bot token from @BotFather
            chat_id (str): Your chat ID where messages will be sent
        """
        self.bot_token = bot_token
        self.chat_id = chat_id
        self.base_url = f"https://api.telegram.org/bot{bot_token}"
    
    def send_message(self, message):
        """
        Send a message to the specified chat
        
        Args:
            message (str): Message to send
            
        Returns:
            bool: True if message sent successfully, False otherwise
        """
        try:
            url = f"{self.base_url}/sendMessage"
            data = {
                "chat_id": self.chat_id,
                "text": message,
                "parse_mode": "HTML"
            }
            
            response = requests.post(url, data=data, timeout=10)
            
            if response.status_code == 200:
                return True
            else:
                print(f"❌ Failed to send Telegram message: {response.status_code} - {response.text}")
                return False
                
        except Exception as e:
            print(f"❌ Error sending Telegram message: {e}")
            return False
    
    def send_profile_created_notification(self, profile_data):
        """
        Send notification when a new profile is created
        
        Args:
            profile_data (dict): Profile data containing email, name, etc.
        """
        timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        
        message = f"""
🆕 <b>New Profile Created</b>

📅 <b>Time:</b> {timestamp}
📧 <b>Email:</b> {profile_data.get('email', 'N/A')}
👤 <b>Name:</b> {profile_data.get('name', 'N/A')}
🔑 <b>Password:</b> {profile_data.get('password', 'N/A')}
📝 <b>Bio:</b> {profile_data.get('biogram', 'N/A')}
🔗 <b>FTL Link:</b> {profile_data.get('ftl', 'N/A')}

✅ <b>Status:</b> Profile creation started
        """.strip()
        
        return self.send_message(message)
    
    def send_profile_completed_notification(self, profile_data, success=True):
        """
        Send notification when profile creation is completed
        
        Args:
            profile_data (dict): Profile data
            success (bool): Whether the profile creation was successful
        """
        timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        
        status_emoji = "✅" if success else "❌"
        status_text = "SUCCESS" if success else "FAILED"
        
        message = f"""
{status_emoji} <b>Profile Creation {status_text}</b>

📅 <b>Time:</b> {timestamp}
📧 <b>Email:</b> {profile_data.get('email', 'N/A')}
👤 <b>Name:</b> {profile_data.get('name', 'N/A')}
🔗 <b>FTL Link:</b> {profile_data.get('ftl', 'N/A')}

{status_emoji} <b>Status:</b> {status_text}
        """.strip()
        
        return self.send_message(message)
    
    def send_error_notification(self, error_message, profile_data=None):
        """
        Send error notification
        
        Args:
            error_message (str): Error message
            profile_data (dict, optional): Profile data if available
        """
        timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        
        # Clean the error message
        cleaned_error = self._clean_error_message(error_message)
        
        message = f"""
❌ <b>Error Occurred</b>

📅 <b>Time:</b> {timestamp}
🚨 <b>Error:</b> {cleaned_error}
        """.strip()
        
        if profile_data:
            message += f"""
📧 <b>Email:</b> {profile_data.get('email', 'N/A')}
🔗 <b>FTL Link:</b> {profile_data.get('ftl', 'N/A')}
            """.strip()
        
        return self.send_message(message)
    
    def send_proxy_error_notification(self, error_message):
        """
        Send proxy error notification
        
        Args:
            error_message (str): Proxy error message
        """
        timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        
        # Clean the error message to remove HTML-like tags that Telegram can't parse
        cleaned_error = self._clean_error_message(error_message)
        
        message = f"""
🌐 <b>Proxy Error</b>

📅 <b>Time:</b> {timestamp}
🚨 <b>Error:</b> {cleaned_error}
🔧 <b>Action:</b> Please check proxy configuration
        """.strip()
        
        # Send message and store the message ID for potential deletion
        success = self.send_message(message)
        if success:
            # Try to get the message ID from the last sent message
            try:
                # Get updates to find the last message sent
                url = f"{self.base_url}/getUpdates"
                response = requests.get(url, timeout=10)
                if response.status_code == 200:
                    updates = response.json().get('result', [])
                    if updates:
                        last_message = updates[-1].get('message', {})
                        if last_message.get('chat', {}).get('id') == int(self.chat_id):
                            self.last_message_id = last_message.get('message_id')
            except:
                pass
        
        return success
    
    def _clean_error_message(self, error_message):
        """Clean error message to remove HTML-like tags and special characters"""
        import re
        
        # Remove HTML-like tags
        cleaned = re.sub(r'<[^>]+>', '', error_message)
        
        # Remove object references like <urllib3.connection.HTTPConnection object at 0x...>
        cleaned = re.sub(r'<[^>]*object at 0x[0-9a-f]+>', '', cleaned)
        
        # Remove extra whitespace and newlines
        cleaned = re.sub(r'\s+', ' ', cleaned)
        
        # Truncate if too long
        if len(cleaned) > 200:
            cleaned = cleaned[:200] + "..."
        
        return cleaned.strip()
    
    def send_email_error_notification(self, email, error_message):
        """
        Send email generation error notification
        
        Args:
            email (str): The email that failed
            error_message (str): Email generation error message
        """
        timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        
        # Clean the error message to remove HTML-like tags that Telegram can't parse
        cleaned_error = self._clean_error_message(error_message)
        
        message = f"""
📧 <b>Email Generation Error</b>

📅 <b>Time:</b> {timestamp}
📧 <b>Email:</b> {email}
🚨 <b>Error:</b> {cleaned_error}
🔧 <b>Action:</b> Check email service configuration
        """.strip()
        
        return self.send_message(message)
    
    def send_iframe_error_notification(self, error_type, error_message, attempt_number, max_attempts):
        """
        Send iframe error notification
        
        Args:
            error_type (str): Type of iframe error
            error_message (str): Detailed error message
            attempt_number (int): Current attempt number
            max_attempts (int): Maximum attempts allowed
        """
        timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        
        # Clean the error message to remove HTML-like tags that Telegram can't parse
        cleaned_error = self._clean_error_message(error_message)
        
        message = f"""
🖼️ <b>Iframe Error Detected</b>

📅 <b>Time:</b> {timestamp}
🚨 <b>Error Type:</b> {error_type}
📝 <b>Details:</b> {cleaned_error}
🔄 <b>Attempt:</b> {attempt_number}/{max_attempts}
🔧 <b>Action:</b> System is attempting to resolve automatically
        """.strip()
        
        return self.send_message(message)
    
    def send_ads_power_limit_notification(self, error_message):
        """
        Send urgent AdsPower profile limit notification
        
        Args:
            error_message (str): The limit error message
        """
        timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        
        # Extract limit number from error message
        import re
        limit_match = re.search(r'limit of (\d+)', error_message)
        limit_number = limit_match.group(1) if limit_match else "UNKNOWN"
        
        message = f"""
🚨 <b>🚨 URGENT: AdsPower Profile Limit Reached! 🚨</b>

📅 <b>Time:</b> {timestamp}
⚠️ <b>Critical Error:</b> Profile creation blocked
🔢 <b>Limit:</b> {limit_number} profiles maximum
🚫 <b>Status:</b> Cannot create new profiles

<b>IMMEDIATE ACTION REQUIRED:</b>
1️⃣ Delete some profiles from AdsPower
2️⃣ Check current profile count
3️⃣ Restart the script after cleanup

<b>Error Details:</b>
{error_message}

<b>⚠️ SYSTEM STOPPED - MANUAL INTERVENTION NEEDED ⚠️</b>
        """.strip()
        
        return self.send_message(message)
    
    def send_and_pin_message(self, message):
        """
        Send a message and pin it to the chat
        
        Args:
            message (str): Message to send and pin
            
        Returns:
            tuple: (success: bool, message_id: int or None)
        """
        try:
            # Send the message
            url = f"{self.base_url}/sendMessage"
            data = {
                "chat_id": self.chat_id,
                "text": message,
                "parse_mode": "HTML"
            }
            
            response = requests.post(url, data=data, timeout=10)
            
            if response.status_code == 200:
                result = response.json()
                message_id = result.get('result', {}).get('message_id')
                
                if message_id:
                    # Pin the message
                    pin_url = f"{self.base_url}/pinChatMessage"
                    pin_data = {
                        "chat_id": self.chat_id,
                        "message_id": message_id,
                        "disable_notification": True
                    }
                    
                    pin_response = requests.post(pin_url, data=pin_data, timeout=10)
                    
                    if pin_response.status_code == 200:
                        return True, message_id
                    else:
                        print(f"❌ Failed to pin message: {pin_response.status_code} - {pin_response.text}")
                        return True, message_id  # Message sent but not pinned
                else:
                    print("❌ Could not get message ID from response")
                    return False, None
            else:
                print(f"❌ Failed to send message: {response.status_code} - {response.text}")
                return False, None
                
        except Exception as e:
            print(f"❌ Error sending and pinning message: {e}")
            return False, None
    
    def unpin_message(self, message_id):
        """
        Unpin a specific message
        
        Args:
            message_id (int): ID of the message to unpin
            
        Returns:
            bool: True if successful, False otherwise
        """
        try:
            url = f"{self.base_url}/unpinChatMessage"
            data = {
                "chat_id": self.chat_id,
                "message_id": message_id
            }
            
            response = requests.post(url, data=data, timeout=10)
            
            if response.status_code == 200:
                return True
            else:
                print(f"❌ Failed to unpin message: {response.status_code} - {response.text}")
                return False
                
        except Exception as e:
            print(f"❌ Error unpinning message: {e}")
            return False
    
    def get_pinned_messages(self):
        """
        Get all pinned messages in the chat
        
        Returns:
            list: List of pinned messages or empty list if error
        """
        try:
            url = f"{self.base_url}/getChat"
            data = {
                "chat_id": self.chat_id
            }
            
            response = requests.post(url, data=data, timeout=10)
            
            if response.status_code == 200:
                result = response.json()
                if result.get('ok'):
                    chat_info = result.get('result', {})
                    pinned_message = chat_info.get('pinned_message')
                    if pinned_message:
                        return [pinned_message]
                    else:
                        return []
                else:
                    return []
            else:
                print(f"❌ Failed to get chat info: {response.status_code} - {response.text}")
                return []
                
        except Exception as e:
            print(f"❌ Error getting pinned messages: {e}")
            return []
    
    def edit_message(self, new_text, message_id):
        """
        Edit an existing message
        
        Args:
            new_text (str): New text for the message
            message_id (int): ID of the message to edit
            
        Returns:
            bool: True if successful, False otherwise
        """
        try:
            url = f"{self.base_url}/editMessageText"
            data = {
                "chat_id": self.chat_id,
                "message_id": message_id,
                "text": new_text,
                "parse_mode": "HTML"
            }
            
            response = requests.post(url, data=data, timeout=10)
            
            if response.status_code == 200:
                result = response.json()
                if result.get('ok'):
                    return True
                else:
                    print(f"❌ Failed to edit message: {result}")
                    return False
            else:
                print(f"❌ Failed to edit message: {response.status_code} - {response.text}")
                return False
                
        except Exception as e:
            print(f"❌ Error editing message: {e}")
            return False
    
    def delete_message(self, message_id):
        """
        Delete a specific message
        
        Args:
            message_id (int): ID of the message to delete
            
        Returns:
            bool: True if successful, False otherwise
        """
        try:
            url = f"{self.base_url}/deleteMessage"
            data = {
                "chat_id": self.chat_id,
                "message_id": message_id
            }
            
            response = requests.post(url, data=data, timeout=10)
            
            if response.status_code == 200:
                return True
            else:
                print(f"❌ Failed to delete message: {response.status_code} - {response.text}")
                return False
                
        except Exception as e:
            print(f"❌ Error deleting message: {e}")
            return False

# Example usage and configuration
def create_telegram_bot():
    """
    Create and return a Telegram bot instance
    You need to set your bot token and chat ID in config.py
    """
    try:
        from config import TELEGRAM_BOT_TOKEN, TELEGRAM_CHAT_ID, ENABLE_TELEGRAM_NOTIFICATIONS
        
        if not ENABLE_TELEGRAM_NOTIFICATIONS:
            print("ℹ️  Telegram notifications are disabled in config.py")
            return None
            
        if TELEGRAM_BOT_TOKEN == "YOUR_BOT_TOKEN_HERE" or TELEGRAM_CHAT_ID == "YOUR_CHAT_ID_HERE":
            print("⚠️  Please configure your Telegram bot token and chat ID in config.py")
            return None
        
        return TelegramBot(TELEGRAM_BOT_TOKEN, TELEGRAM_CHAT_ID)
        
    except ImportError:
        print("⚠️  config.py not found. Please create it with your Telegram bot settings.")
        return None
    except Exception as e:
        print(f"❌ Error creating Telegram bot: {e}")
        return None
