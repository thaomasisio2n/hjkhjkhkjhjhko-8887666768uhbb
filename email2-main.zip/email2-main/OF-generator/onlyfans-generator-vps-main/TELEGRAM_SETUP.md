# Telegram Bot Setup Guide

This guide will help you set up Telegram notifications for your OnlyFans profile generator.

## Step 1: Create a Telegram Bot

1. Open Telegram and search for `@BotFather`
2. Start a chat with BotFather
3. Send `/newbot` command
4. Follow the instructions to create your bot:
   - Choose a name for your bot
   - Choose a username (must end with 'bot')
5. BotFather will give you a **bot token** - save this!

## Step 2: Get Your Chat ID

### Method 1: Using @userinfobot

1. Search for `@userinfobot` in Telegram
2. Start a chat with it
3. It will automatically send you your chat ID

### Method 2: Using your bot

1. Start a chat with your bot
2. Send any message to your bot
3. Visit this URL in your browser (replace with your bot token):
   ```
   https://api.telegram.org/botYOUR_BOT_TOKEN_HERE/getUpdates
   ```
4. Look for the "chat" object and find your "id" number

## Step 3: Configure the Bot

1. Open `config.py` in your project
2. Replace the placeholder values:
   ```python
   TELEGRAM_BOT_TOKEN = "1234567890:ABCdefGHIjklMNOpqrsTUVwxyz"  # Your actual bot token
   TELEGRAM_CHAT_ID = "123456789"  # Your actual chat ID
   ```

## Step 4: Test the Bot

1. Make sure your bot is configured correctly
2. Run your main script:
   ```bash
   python3 main.py
   ```
3. You should receive Telegram notifications when:
   - A new profile is created
   - Profile creation is completed (success/failure)
   - Errors occur

## Notification Types

The bot will send you notifications for:

- 🆕 **Profile Created**: When a new profile creation starts
- ✅ **Profile Success**: When profile creation completes successfully
- ❌ **Profile Failed**: When profile creation fails
- 🚨 **Errors**: When any errors occur during the process

## Troubleshooting

### Bot not sending messages?

1. Make sure you've started a chat with your bot
2. Verify your bot token and chat ID are correct
3. Check that `ENABLE_TELEGRAM_NOTIFICATIONS = True` in config.py

### Getting "Forbidden" errors?

- Make sure you've started a chat with your bot first
- The bot needs to be added to the chat where you want to receive messages

### Bot token invalid?

- Double-check your bot token from BotFather
- Make sure there are no extra spaces or characters

## Security Notes

- Keep your bot token private
- Don't share your config.py file with others
- Consider using environment variables for production use

## Example Configuration

```python
# config.py
TELEGRAM_BOT_TOKEN = "1234567890:ABCdefGHIjklMNOpqrsTUVwxyz"
TELEGRAM_CHAT_ID = "123456789"
ENABLE_TELEGRAM_NOTIFICATIONS = True
```
