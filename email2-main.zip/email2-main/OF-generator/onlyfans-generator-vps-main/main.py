import random
import time
import traceback
from adspower.adspower_profile import createProfile, stopAndDeleteBroswer
from assign import get_random_available_link, mark_link_as_used
from card import   getCardDetails, switch_to_iframe_and_fill_card_details_form
from email_generator import blocking, get_email
from ftl import confirm_ftl
from privacy import  changePrivacy
from profileActions import change_username
from profileDefs import generate_bio, generate_full_name, generate_password
from register import register
from adspower.setup__browser import setup_browser
from slenium_functions import random_wait
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.common.exceptions import NoSuchWindowException, WebDriverException
from telegram_bot import create_telegram_bot
from accounts_manager import AccountsManager
from proxy_tester import ProxyTester
from proxy_error_tracker import ProxyErrorTracker

def ensure_driver_window_alive(driver, retries=3):
    """
    AdsPower + remote-debugging potrafi chwilowo zgubić aktywne okno.
    Próbujemy przełączyć się na istniejące okno albo utworzyć nową kartę.
    """
    for attempt in range(retries):
        try:
            handles = driver.window_handles
            if handles:
                driver.switch_to.window(handles[0])
                _ = driver.current_url
                return True
            driver.switch_to.new_window("tab")
            driver.get("about:blank")
            return True
        except Exception as e:
            print(f"⚠️ Window recovery attempt {attempt + 1}/{retries} failed: {e}")
            random_wait(1, 2)
    return False

def get_card_details_with_retry(driver, retries=3):
    last_error = None
    for attempt in range(retries):
        if not ensure_driver_window_alive(driver):
            last_error = RuntimeError("No alive browser window available.")
            continue
        try:
            return getCardDetails(driver)
        except (NoSuchWindowException, WebDriverException) as e:
            last_error = e
            print(f"⚠️ getCardDetails retry {attempt + 1}/{retries} due to window/session issue: {e}")
            random_wait(1, 3)
    raise Exception(f"Failed to get card details after {retries} attempts: {last_error}")

def main(ftl,driver,profileId, telegram_bot=None, accounts_manager=None, proxy_tester=None, error_tracker=None):
    try:
        # Test proxy before starting
        if proxy_tester:
            print("🔍 Testing proxy before starting...")
            proxy_result = proxy_tester.test_proxy_with_retry()
            
            if not proxy_result['working']:
                # Record the profile failure
                if error_tracker:
                    error_tracker.record_profile_failure()
                
                # Only send notification after 3 consecutive failures
                if error_tracker and error_tracker.should_send_proxy_notification():
                    # Categorize the error
                    error_type = proxy_tester.categorize_error(proxy_result['error'])
                    
                    # Check if we should send notification (cooldown check)
                    notification_info = error_tracker.should_send_notification(error_type)
                    
                    if notification_info['should_send']:
                        error_summary = error_tracker.get_error_summary(error_type)
                        print(f"🚨 {error_summary}")
                        if telegram_bot:
                            # Send notification and store message ID for later deletion
                            success = telegram_bot.send_proxy_error_notification(error_summary)
                            if success and hasattr(telegram_bot, 'last_message_id'):
                                error_tracker.set_error_message_id(telegram_bot.last_message_id)
                    else:
                        print(f"⚠️  Proxy error notification on cooldown: {error_type} - {notification_info['error_count']} times")
                else:
                    print(f"⚠️  Proxy error (not enough consecutive failures yet): {proxy_result['error']}")
                
                return False
        
        # Generate email with error handling
        try:
            email = get_email("outlook.com")
            if not email or not email.get("email") or email.get("email") == "error":
                raise Exception("Failed to generate email")
        except Exception as e:
            error_msg = f"Email generation failed: {str(e)}"
            print(f"❌ {error_msg}")
            if telegram_bot:
                telegram_bot.send_email_error_notification("N/A", error_msg)
            return False
        
        profile_data = {
            "email": email["email"],
            "emailID": email["id"],
            "password": generate_password(),
            "name": generate_full_name(),
            "biogram": generate_bio(),
            "username": "get_random_Uname()",
            "ftl":ftl
         }
        print(f"Generated profile data: {profile_data}")
        
        # Send Telegram notification when profile creation starts

        if driver:
          current_step = "init"
          try:
              current_step = "get_card_details"
              card = get_card_details_with_retry(driver)
              print("Card",card)
              current_step = "register"
              register(driver, profile_data)
              current_step = "wait_email_link"
              link = blocking(profile_data["emailID"])
              current_step = "open_verification_link"
              driver.get(link)
              time.sleep(4)
              current_step = "open_add_card_page"
              driver.get("https://onlyfans.com/my/payments/add_card")
              random_wait(4, 8)
              current_step = "fill_card_iframe"
              switch_to_iframe_and_fill_card_details_form(driver, card, telegram_bot=telegram_bot)
              current_step = "wait_payments_url"
              WebDriverWait(driver, 20).until(EC.url_to_be("https://onlyfans.com/my/payments/"))
              current_step = "confirm_ftl"
              confirm_ftl(driver, profile_data)
              random_wait(5, 6)
              current_step = "change_privacy"
              changePrivacy(driver)   
              random_wait(5, 6)
              if random.randint(0, 1) == 0:
                current_step = "change_username"
                print("changing useram  ")
                change_username(driver,profile_data)
              random_wait(5, 6)
              
              # Update accounts and pin message (this also updates the counter)
              if accounts_manager:
                  accounts_manager.update_and_pin(ftl)
              
              # Record successful profile creation (resets consecutive failures)
              if error_tracker:
                  error_tracker.record_profile_success(telegram_bot)
              
              # Send success notification
              if telegram_bot:
                  print("sending profile completed notification")
                #   telegram_bot.send_profile_completed_notification(profile_data, success=True)
              
              return True  # Return success
              
          except Exception as e:
              print(f"✈️ Flow failed at step={current_step}")
              print(f"✈️ Exception type={type(e).__name__}, details={repr(e)}")
              try:
                  print(f"✈️ Current URL={driver.current_url}")
              except Exception:
                  print("✈️ Current URL unavailable")
              print(traceback.format_exc())
              
              # Check if this is an AdsPower limit error
              if "ADSPOWER_LIMIT_ERROR" in str(e):
                  print("🚨 CRITICAL: AdsPower profile limit reached!")
                  if telegram_bot:
                      telegram_bot.send_ads_power_limit_notification(str(e))
                  # Don't continue - this is a critical error that needs manual intervention
                  print("🛑 SYSTEM STOPPED - Manual intervention required")
                  return False
              else:
                  # Regular error notification
                  if telegram_bot:
                      telegram_bot.send_error_notification(str(e), profile_data)
              
              stopAndDeleteBroswer(profileId)
          finally:
              print("✈️", "Registration process completed.")
              stopAndDeleteBroswer(profileId)
        else:
          stopAndDeleteBroswer(profileId)
          return False
    except Exception as e:
        print(f"✈️ Outer main() exception type={type(e).__name__}, details={repr(e)}")
        print(traceback.format_exc())
        stopAndDeleteBroswer(profileId)
        return False
        

if __name__ == "__main__":
    # Initialize Telegram bot
    telegram_bot = create_telegram_bot()
    
    # Initialize Accounts Manager
    accounts_manager = AccountsManager(telegram_bot)
    
    # Initialize Proxy Tester
    proxy_tester = ProxyTester()
    
    # Initialize Error Tracker
    error_tracker = ProxyErrorTracker()
    
    # Pin initial accounts status (will update existing if found)
    if telegram_bot:
        accounts_manager.update_and_pin()
    
    profileId = None
    while True:
        try:
            profileId = None
            ftl = get_random_available_link()
            if ftl is None:
                print("✈️ All links reached the daily limit.")
                break
            
            # Try to create profile - this might fail due to limit
            try:
                profileId = createProfile()
            except Exception as e:
                if "ADSPOWER_LIMIT_ERROR" in str(e):
                    print("🚨 CRITICAL: AdsPower profile limit reached in main loop!")
                    if telegram_bot:
                        telegram_bot.send_ads_power_limit_notification(str(e))
                    print("🛑 SYSTEM STOPPED - Manual intervention required")
                    break  # Exit the loop completely
                else:
                    # Re-raise other profile creation errors
                    raise e
            
            driver = setup_browser(profileId)
            if driver:
                success = main(ftl, driver, profileId, telegram_bot, accounts_manager, proxy_tester, error_tracker)
                if not success:
                    print("❌ Profile creation failed due to proxy or email issues")
                    stopAndDeleteBroswer(profileId)
                    random_wait(10, 15)  # Wait longer before retry
                    continue
            else:
                print("❌ Nie udało się uruchomić przeglądarki.")
                # Send error notification for browser startup failure
                if telegram_bot:
                    telegram_bot.send_error_notification("Failed to start browser", {"ftl": ftl})
                stopAndDeleteBroswer(profileId)
        except Exception as e:
            print(f"✈️ Loop exception type={type(e).__name__}, details={repr(e)}")
            print(traceback.format_exc())
            # Send error notification for general exceptions
            if telegram_bot:
                telegram_bot.send_error_notification(str(e))
            if profileId:
                stopAndDeleteBroswer(profileId)
            random_wait(5, 10)
            continue


#  mrotzis.com
# ratixq.com
# meefff.com