from slenium_functions import random_wait, wait_for_element
from selenium.webdriver.common.by import By


def confirm_ftl(driver,profile_data):
  ftl = profile_data["ftl"]
  driver.get(ftl)
  el = wait_for_element(driver,"//button[normalize-space(text())='Confirm']",SearchType=By.XPATH)
  random_wait()
  el.click()
  random_wait(10, 12)