import time
import traceback
from slenium_functions import random_wait, type_with_delay, wait_for_element
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.common.keys import Keys
from selenium.common.exceptions import TimeoutException, WebDriverException, NoSuchElementException
import re

from zipcode import  get_random_zip


def getCardDetails(driver):
    current_url = driver.current_url
    driver.get("https://ccardgenerator.com/generat-visa-card-numbers.php")
    number = wait_for_element(driver, "inputiRandomCardNumber",SearchType=By.ID).text
    name = wait_for_element(driver, "inputiRandomName",SearchType=By.ID).text
    cvv = wait_for_element(driver, "inputiRandomCVV",SearchType=By.ID).text
    expiration = wait_for_element(driver, "inputiRandomExp",SearchType=By.ID).text
    driver.get(current_url)
    return {
            "number": number,
            "name": name,
            "cvv": cvv,
            "expiration": expiration
        }


def detect_iframe_error(driver):
    """
    Simple iframe error detection - just check if the first input field is present
    Returns: (has_error, error_type, error_message)
    """
    try:
        # Simple check: if we can find the first input field, iframe is working
        first_input = driver.find_elements(By.CSS_SELECTOR, "input[placeholder='Name on the card']")
        if first_input:
            print("✅ Found 'Name on the card' input - iframe is working")
            return False, None, None  # No error, form is present
        
        # If no input found, check if it's a different placeholder
        alternative_inputs = driver.find_elements(By.CSS_SELECTOR, "input[placeholder*='card'], input[placeholder*='Card'], input[placeholder*='name'], input[placeholder*='Name']")
        if alternative_inputs:
            print(f"✅ Found alternative inputs: {[el.get_attribute('placeholder') for el in alternative_inputs[:3]]} - iframe is working")
            return False, None, None  # No error, some form input is present
        
        # Only consider it an error if no input fields are found at all
        print("❌ No form inputs found - iframe error detected")
        return True, "no_form_inputs", "No form input fields found in iframe"
        
    except Exception as e:
        print(f"❌ Error during iframe detection: {str(e)}")
        return True, "detection_error", f"Error during iframe error detection: {str(e)}"


def handle_iframe_error(driver, error_type, error_message, max_retries=3, telegram_bot=None):
    """
    Simple iframe error handling - just refresh and retry
    """
    print(f"🚨 Iframe error detected: {error_type} - {error_message}")
    
    # Send Telegram notification if bot is available
    if telegram_bot:
        try:
            telegram_bot.send_iframe_error_notification(error_type, error_message, 1, max_retries)
        except Exception as e:
            print(f"⚠️  Failed to send Telegram notification: {str(e)}")
    
    for attempt in range(max_retries):
        print(f"🔄 Attempting to fix iframe error (attempt {attempt + 1}/{max_retries})")
        
        try:
            # Simple strategy: refresh the page and try again
            driver.switch_to.default_content()
            driver.refresh()
            random_wait(3, 5)
            
            # Wait for iframe and switch to it
            wait = WebDriverWait(driver, 15)
            iframe = wait.until(EC.presence_of_element_located((By.TAG_NAME, "iframe")))
            driver.switch_to.frame(iframe)
            random_wait(2, 3)
            
            # Check if error is resolved
            has_error, _, _ = detect_iframe_error(driver)
            if not has_error:
                print(f"✅ Iframe error resolved on attempt {attempt + 1}")
                return True
                
        except Exception as e:
            print(f"⚠️  Error handling attempt {attempt + 1}: {str(e)}")
            driver.switch_to.default_content()
            random_wait(2, 4)
    
    print(f"❌ Failed to resolve iframe error after {max_retries} attempts")
    return False


def switch_to_iframe_and_fill_card_details_form(driver, card, timeout=120, max_retries=3, telegram_bot=None):
    """
    Enhanced version with iframe error detection and handling
    """
    for attempt in range(max_retries):
        try:
            print(f"🔄 Attempting to fill card form (attempt {attempt + 1}/{max_retries})")
            
            # Wait for iframe and switch to it
            wait = WebDriverWait(driver, timeout)
            iframe = wait.until(EC.presence_of_element_located((By.TAG_NAME, "iframe")))
            driver.switch_to.frame(iframe)
            
            # Check for iframe errors
            random_wait(2, 3)
            has_error, error_type, error_message = detect_iframe_error(driver)
            
            if has_error:
                print(f"⚠️  Iframe error detected: {error_type}")
                if not handle_iframe_error(driver, error_type, error_message, telegram_bot=telegram_bot):
                    if attempt == max_retries - 1:
                        raise Exception(f"Failed to resolve iframe error after {max_retries} attempts: {error_message}")
                    continue
                else:
                    # Error was resolved, continue with form filling
                    pass
            
            # Now fill the form
            fields = {
                "input[placeholder='Name on the card']": card["name"],
                "input[placeholder='Card Number']": card["number"],
                "input[placeholder='CVC']": card["cvv"],
                "input[placeholder='MM']": card["expiration"].split("/")[0],
                "input[placeholder='YY']": card["expiration"].split("/")[1][-2:],
            }
            
            for selector, value in fields.items():
                el = wait_for_element(driver, selector)
                el.click()
                random_wait()
                type_with_delay(el, value)

            # Fill additional fields
            wait_for_element(driver, 'input[placeholder="Country"]').click()
            wait_for_element(driver, "li[data-code='US']").click()
            wait_for_element(driver, 'input[placeholder="State / Province"]').click()
            wait_for_element(driver, "li[data-name='California']").click()
            wait_for_element(driver, 'input[placeholder="Address"]').click()
            el_adress = wait_for_element(driver, 'input[placeholder="Address"]')
            type_with_delay(el_adress, get_random_zip())
            random_wait(1, 3)
            el_adress.send_keys(Keys.ENTER)
            random_wait(1, 3)
            wait_for_element(driver, 'label').click()
            
            # Switch back to default content
            driver.switch_to.default_content()
            random_wait(3, 4)
            
            # Submit the form
            button = wait_for_element(driver, "button[class='g-btn m-rounded']")
            button.click()
            print("about to wait for 20")
            
            random_wait(40, 46)
            print("waited for 20")
            
            # Handle potential second button click
            try:
                sub23 = wait_for_element(driver, "button[class='g-btn m-rounded']", timeout=2)
                print("found button")
                if sub23:
                    try:
                        sub23.click()
                        print("clicked")
                    except Exception as e:
                        print(
                            f"error clicking second button: type={type(e).__name__}, details={repr(e)}"
                        )
                        print(traceback.format_exc())
            except Exception as e:
                print(f"no second button found / lookup failed: type={type(e).__name__}, details={repr(e)}")
                print("no second button found")
            
            print("Card form completed successfully!")
            return True
            
        except Exception as e:
            print(
                f"❌ Error on attempt {attempt + 1}: type={type(e).__name__}, details={repr(e)}"
            )
            print(traceback.format_exc())
            driver.switch_to.default_content()
            
            if attempt == max_retries - 1:
                raise Exception(f"Failed to fill card form after {max_retries} attempts: {str(e)}")
            
            # Wait before retry
            random_wait(5, 10)
    
    return False


def wait_for_enabled_button(driver, selector, timeout=30):
    return WebDriverWait(driver, timeout).until(
        lambda d: (
            (btn := d.find_element(By.CSS_SELECTOR, selector))
            and btn.is_enabled()
            and btn.get_attribute("disabled") in [None, "false"]
        )
    )