# Telegram Bot Configuration
TELEGRAM_BOT_TOKEN = "8391037449:AAE2VKVwltrjnsGA8vkHn1pgIvYDSYkWZ5c"  # Get this from @BotFather
TELEGRAM_CHAT_ID = "5012533617"      # Your chat ID where messages will be sent

# Enable/Disable Telegram notifications
ENABLE_TELEGRAM_NOTIFICATIONS = True

# Notification settings
NOTIFY_ON_PROFILE_CREATED = True
NOTIFY_ON_PROFILE_COMPLETED = True
NOTIFY_ON_ERRORS = True
NOTIFY_ON_BROWSER_FAILURE = True

# AdsPower Configuration
ADSPOWER_PROFILE_NAME = "2(DO NOT TOUCH)"
ADSPOWER_GROUP_ID = "6171015"

# Proxy Configuration
PROXY_TYPE = "http"
PROXY_HOST = "us5.4g.iproyal.com"
PROXY_PORT = "8533"
PROXY_USER = "s9ZPK7D"
PROXY_PASSWORD = "Yjn12JzFzRcHszP"
PROXY_SOFT = "brightdata"

# Proxy Rotation
PROXY_ROTATION_URL = "https://apid.iproyal.com/v1/orders/72171608/rotate-ip/beMzMensBdPV"

# Other configuration options 
MAX_RETRY_ATTEMPTS = 3
WAIT_TIME_BETWEEN_ATTEMPTS = 5  # seconds

