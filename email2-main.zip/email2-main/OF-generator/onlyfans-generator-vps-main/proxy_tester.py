import requests
import time
import re
from config import PROXY_HOST, PROXY_PORT, PROXY_USER, PROXY_PASSWORD

class ProxyTester:
    def __init__(self):
        self.proxy_config = {
            'http': f'http://{PROXY_USER}:{PROXY_PASSWORD}@{PROXY_HOST}:{PROXY_PORT}',
            'https': f'http://{PROXY_USER}:{PROXY_PASSWORD}@{PROXY_HOST}:{PROXY_PORT}'
        }
        self.test_urls = [
            'http://httpbin.org/ip',
            'https://api.ipify.org?format=json',
            'http://ip-api.com/json'
        ]
    
    def categorize_error(self, error_message):
        """Categorize the error type based on error message"""
        error_lower = error_message.lower()
        
        if '407' in error_message or 'authentication' in error_lower or 'auth' in error_lower:
            return 'authentication'
        elif 'timeout' in error_lower:
            return 'timeout'
        elif 'connection refused' in error_lower or 'cannot connect' in error_lower:
            return 'connection'
        elif 'dns' in error_lower or 'name resolution' in error_lower:
            return 'dns'
        else:
            return 'unknown'
    
    def test_proxy(self, timeout=10):
        """
        Test if proxy is working
        
        Returns:
            dict: {'working': bool, 'ip': str, 'error': str}
        """
        for test_url in self.test_urls:
            try:
                print(f"🔍 Testing proxy with {test_url}...")
                
                response = requests.get(
                    test_url, 
                    proxies=self.proxy_config, 
                    timeout=timeout,
                    headers={
                        'User-Agent': 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36'
                    }
                )
                
                if response.status_code == 200:
                    try:
                        data = response.json()
                        ip = data.get('ip') or data.get('origin') or data.get('query')
                        if ip:
                            print(f"✅ Proxy working! IP: {ip}")
                            return {
                                'working': True,
                                'ip': ip,
                                'error': None
                            }
                    except:
                        # If JSON parsing fails, check if we got any response
                        if response.text:
                            print(f"✅ Proxy working! Response received")
                            return {
                                'working': True,
                                'ip': 'Unknown',
                                'error': None
                            }
                
            except requests.exceptions.ProxyError as e:
                print(f"❌ Proxy error: {e}")
                return {
                    'working': False,
                    'ip': None,
                    'error': f"Proxy connection failed: {str(e)}"
                }
            except requests.exceptions.Timeout as e:
                print(f"❌ Proxy timeout: {e}")
                return {
                    'working': False,
                    'ip': None,
                    'error': f"Proxy timeout: {str(e)}"
                }
            except requests.exceptions.RequestException as e:
                print(f"❌ Request error: {e}")
                continue
            except Exception as e:
                print(f"❌ Unexpected error: {e}")
                continue
        
        return {
            'working': False,
            'ip': None,
            'error': "All test URLs failed"
        }
    
    def test_proxy_with_retry(self, max_retries=3, delay=5):
        """
        Test proxy with retries
        
        Returns:
            dict: {'working': bool, 'ip': str, 'error': str}
        """
        for attempt in range(max_retries):
            print(f"🔄 Proxy test attempt {attempt + 1}/{max_retries}")
            
            result = self.test_proxy()
            
            if result['working']:
                return result
            
            if attempt < max_retries - 1:
                print(f"⏳ Waiting {delay} seconds before retry...")
                time.sleep(delay)
        
        return result
