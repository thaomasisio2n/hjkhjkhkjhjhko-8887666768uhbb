import json
import os
from datetime import datetime
from config import ADSPOWER_PROFILE_NAME, PROXY_PORT

class AccountsManager:
    def __init__(self, telegram_bot=None):
        self.accounts_file = "accounts.json"
        self.telegram_bot = telegram_bot
        self.pinned_message_id = None
        
    def load_accounts(self):
        """Load accounts from JSON file"""
        try:
            if os.path.exists(self.accounts_file):
                with open(self.accounts_file, 'r') as f:
                    return json.load(f)
            else:
                return []
        except Exception as e:
            print(f"❌ Error loading accounts: {e}")
            return []
    
    def save_accounts(self, accounts):
        """Save accounts to JSON file"""
        try:
            with open(self.accounts_file, 'w') as f:
                json.dump(accounts, f, indent=4)
        except Exception as e:
            print(f"❌ Error saving accounts: {e}")
    
    def update_account_created_today(self, link):
        """
        Update the created_today count for a specific link
        This replaces the mark_link_as_used function to avoid double counting
        """
        accounts = self.load_accounts()
        
        for account in accounts:
            if account.get('link') == link:
                account['created_today'] = account.get('created_today', 0) + 1
                account['last_updated'] = datetime.now().strftime("%Y-%m-%d")
                print(f"✅✅✅✅✅✅ Updated account counter: {account['created_today']}/{account['daily_goal']} for {link}")
                break
        
        self.save_accounts(accounts)
        return accounts
    
    def format_accounts_for_telegram(self, accounts):
        """Format accounts data for Telegram message"""
        timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        
        # Create header with AdsPower profile name and proxy port
        header = f"""
📊 <b>Accounts Status</b>
👤 <b>Profile:</b> {ADSPOWER_PROFILE_NAME}
🌐 <b>Proxy Port:</b> {PROXY_PORT}
📅 <b>Updated:</b> {timestamp}

        🔗 <b>Links Status:</b>
        """.strip()
        
        # Format each account
        accounts_text = ""
        for i, account in enumerate(accounts, 1):
            link = account.get('link', 'N/A')
            daily_goal = account.get('daily_goal', 0)
            created_today = account.get('created_today', 0)
            last_updated = account.get('last_updated', 'N/A')
            
            # Extract creator name from URL
            creator_name = self._extract_creator_name(link)
            
            # Calculate progress
            progress = (created_today / daily_goal * 100) if daily_goal > 0 else 0
            progress_bar = self._create_progress_bar(progress)
            
            accounts_text += f"""
{i}. <b>Creator:</b> {creator_name}
   📈 <b>Progress:</b> {created_today}/{daily_goal} ({progress:.1f}%)
   {progress_bar}
   📅 <b>Last Updated:</b> {last_updated}
            """.strip() + "\n\n"
        
        return header + "\n" + accounts_text
    
    def _extract_creator_name(self, url):
        """Extract creator name from OnlyFans URL"""
        try:
            if 'onlyfans.com' in url:
                # Extract the creator name from URL like: https://onlyfans.com/creatorname/trial/...
                parts = url.split('/')
                if len(parts) >= 4:
                    return parts[3]  # creator name is the 4th part
            return url  # Return original if not a valid OnlyFans URL
        except:
            return url
    
    def _create_progress_bar(self, percentage):
        """Create a visual progress bar"""
        filled = int(percentage / 10)
        empty = 10 - filled
        return "█" * filled + "░" * empty
    
    def pin_accounts_message(self, accounts):
        """Pin the accounts message to Telegram"""
        if not self.telegram_bot:
            print("⚠️  Telegram bot not configured, skipping pin")
            return
        
        try:
            # Format the message
            message = self.format_accounts_for_telegram(accounts)
            
            # Check if there's already a pinned message with same proxy port
            existing_message_id = self.find_existing_pinned_message()
            
            if existing_message_id:
                # Update existing message
                success = self.telegram_bot.edit_message(message, existing_message_id)
                if success:
                    self.pinned_message_id = existing_message_id
                    print(f"✅ Existing accounts message updated (ID: {existing_message_id})")
                else:
                    print("❌ Failed to update existing message, creating new one")
                    self.create_new_pinned_message(message)
            else:
                # Create new pinned message
                self.create_new_pinned_message(message)
                
        except Exception as e:
            print(f"❌ Error pinning accounts message: {e}")
    
    def find_existing_pinned_message(self):
        """Find existing pinned message with same proxy port"""
        try:
            # Get pinned messages
            pinned_messages = self.telegram_bot.get_pinned_messages()
            
            if not pinned_messages:
                return None
            
            # Look for message containing our proxy port
            for msg in pinned_messages:
                if msg.get('text') and f"Proxy Port: {PROXY_PORT}" in msg.get('text', ''):
                    return msg.get('message_id')
            
            return None
            
        except Exception as e:
            print(f"❌ Error finding existing pinned message: {e}")
            return None
    
    def create_new_pinned_message(self, message):
        """Create a new pinned message"""
        try:
            # If we have a previous pinned message, unpin it first
            if self.pinned_message_id:
                try:
                    self.telegram_bot.unpin_message(self.pinned_message_id)
                except:
                    pass  # Ignore errors if message doesn't exist
            
            # Send new message and pin it
            success, message_id = self.telegram_bot.send_and_pin_message(message)
            
            if success:
                self.pinned_message_id = message_id
                print(f"✅ New accounts message pinned successfully (ID: {message_id})")
            else:
                print("❌ Failed to pin new accounts message")
                
        except Exception as e:
            print(f"❌ Error creating new pinned message: {e}")
    
    def update_and_pin(self, link=None):
        """Update accounts and pin the message"""
        if link:
            accounts = self.update_account_created_today(link)
        else:
            accounts = self.load_accounts()
        
        self.pin_accounts_message(accounts)
        return accounts
