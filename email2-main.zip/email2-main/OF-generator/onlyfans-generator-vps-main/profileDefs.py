import random
import string

import pandas as pd
from email_generator import get_email
import random
from faker import Faker
fake = Faker()


# Przykład użycia
def generate_bio():
    bio = "id bro"
    return bio


def generate_full_name():
    df = pd.read_csv("csv/name.csv")
    names = df['abbott'].dropna().tolist()
    names = [name for name in names if str(name).strip().lower() != 'nan' and str(name).strip() != '']
    while True:
        name = random.choice(names)
        name_str = str(name).strip()
        if name_str and name_str.lower() != 'nan':
            return name_str
        


def generate_username():
    df = pd.read_csv("csv/username.csv")
    random_author = random.choice(df['author'].tolist())
    return random_author

def generate_password():
    length = 12
    lowercase = string.ascii_lowercase
    uppercase = string.ascii_uppercase
    digits = string.digits
    punctuation = string.punctuation
    password = [
        random.choice(lowercase),  # Mała litera
        random.choice(uppercase),  # Duża litera
        random.choice(digits),     # Cyfra
        random.choice(punctuation) # Znak specjalny
    ]
    all_characters = lowercase + uppercase + digits + punctuation
    password += random.choices(all_characters, k=length - 4)
    random.shuffle(password)
    return ''.join(password)


