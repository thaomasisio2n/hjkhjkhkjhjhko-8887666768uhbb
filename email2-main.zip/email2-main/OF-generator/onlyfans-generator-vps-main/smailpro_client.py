"""
SmailPro / Sonjj API client (jak w reddit-poster/src/lib/smailpro.ts).
Dokumentacja: https://smailpro.com/temporary-email
API base: https://app.sonjj.com
"""

import json
import os
from typing import Any, Dict, List, Optional, Tuple

import requests

try:
    from dotenv import load_dotenv
    from pathlib import Path

    for _parent in [Path.cwd(), *Path.cwd().parents, Path(__file__).resolve().parent, *Path(__file__).resolve().parents]:
        env_file = _parent / ".env"
        if env_file.is_file():
            load_dotenv(env_file)
            break
    else:
        load_dotenv()
except ImportError:
    pass

SMAILPRO_BASE_URL = "https://app.sonjj.com"


class SmailProError(Exception):
    def __init__(self, message: str, status: Optional[int] = None, remaining_credit: Optional[str] = None):
        super().__init__(message)
        self.status = status
        self.remaining_credit = remaining_credit


def _get_api_key() -> str:
    key = (os.getenv("SMAILPRO_API_KEY") or os.getenv("SONJJ_API_KEY") or "").strip()
    if not key:
        raise SmailProError(
            "Brak klucza SmailPro. Ustaw SMAILPRO_API_KEY lub SONJJ_API_KEY w .env (my.sonjj.com)."
        )
    return key


def is_smali_pro_configured() -> bool:
    return bool((os.getenv("SMAILPRO_API_KEY") or os.getenv("SONJJ_API_KEY") or "").strip())


def _error_text(value: Any) -> str:
    if value is None:
        return ""
    if isinstance(value, str):
        return value
    if isinstance(value, list):
        return "; ".join(filter(None, (_error_text(v) for v in value)))
    if isinstance(value, dict):
        err = value.get("error")
        if isinstance(err, dict) and err.get("message") is not None:
            nested = _error_text(err.get("message"))
            if nested:
                return nested
        if value.get("message") is not None:
            m = _error_text(value.get("message"))
            if m:
                return m
        if value.get("msg") is not None:
            return _error_text(value.get("msg"))
    try:
        return json.dumps(value)
    except Exception:
        return str(value)


class SmailProClient:
    def __init__(self, api_key: Optional[str] = None, proxies: Optional[Dict[str, str]] = None):
        self.api_key = api_key or _get_api_key()
        self.session = requests.Session()
        self.session.headers.update({
            "X-Api-Key": self.api_key,
            "Content-Type": "application/json",
        })
        if proxies:
            self.session.proxies.update(proxies)

    def _get(self, path: str, params: Optional[Dict[str, Any]] = None) -> Tuple[Any, Optional[str]]:
        response = self.session.get(
            f"{SMAILPRO_BASE_URL}{path}",
            params={k: v for k, v in (params or {}).items() if v is not None and v != ""},
            timeout=30,
        )
        remaining_credit = response.headers.get("x-remaining-credit")

        if not response.ok:
            message = f"SmailPro API error: {response.status_code} {response.reason}"
            try:
                body = response.json()
                from_api = _error_text(body)
                if from_api and not from_api.startswith("{"):
                    message = from_api
            except Exception:
                pass
            if response.status_code == 402:
                message = (
                    "Brak kredytów SmailPro (402). Doładuj konto na my.sonjj.com."
                )
                if remaining_credit:
                    message += f" Pozostało: {remaining_credit}."
            raise SmailProError(message, response.status_code, remaining_credit)

        return response.json(), remaining_credit

    def random_gmail(self, gmail_type: str = "alias", password: Optional[str] = None) -> Dict[str, Any]:
        """GET /v1/temp_gmail/random (~0.5 credits). Zwraca email, timestamp, type."""
        params = {"type": gmail_type}
        if password:
            params["password"] = password
        data, remaining_credit = self._get("/v1/temp_gmail/random", params)
        data["remainingCredit"] = remaining_credit
        return data

    def gmail_inbox(self, email: str, timestamp: int) -> List[Dict[str, Any]]:
        """GET /v1/temp_gmail/inbox (~0.05 credits)."""
        data, _ = self._get("/v1/temp_gmail/inbox", {"email": email, "timestamp": timestamp})
        return data.get("messages") or []

    def gmail_message(self, email: str, mid: str) -> str:
        """GET /v1/temp_gmail/message (~1.5 credits)."""
        data, _ = self._get("/v1/temp_gmail/message", {"email": email, "mid": mid})
        return data.get("body") or ""

    def random_outlook(self, outlook_type: str = "real") -> Dict[str, Any]:
        """GET /v1/temp_outlook/random (~0.5 credits). Zwraca email, timestamp, type."""
        data, remaining_credit = self._get("/v1/temp_outlook/random", {"type": outlook_type})
        data["remainingCredit"] = remaining_credit
        return data

    def outlook_inbox(self, email: str, timestamp: int) -> List[Dict[str, Any]]:
        """GET /v1/temp_outlook/inbox (~0.05 credits)."""
        data, _ = self._get("/v1/temp_outlook/inbox", {"email": email, "timestamp": timestamp})
        return data.get("messages") or []

    def outlook_message(self, email: str, mid: str) -> str:
        """GET /v1/temp_outlook/message (~2 credits)."""
        data, _ = self._get("/v1/temp_outlook/message", {"email": email, "mid": mid})
        return data.get("body") or ""
