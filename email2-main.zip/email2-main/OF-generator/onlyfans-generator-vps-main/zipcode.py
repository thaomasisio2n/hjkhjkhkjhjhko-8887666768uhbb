import random

# Zakresy ZIP kodów, które należą do stanów, których NIE chcemy
excluded_ranges = [
    (350, 369),  # Alabama
    (716, 729),  # Arkansas
    (320, 349),  # Florida
    (300, 319),  # Georgia
    (832, 839),  # Idaho
    (460, 479),  # Indiana
    (660, 679),  # Kansas
    (400, 427),  # Kentucky
    (700, 715),  # Louisiana
    (386, 397),  # Mississippi
    (590, 599),  # Montana
    (680, 693),  # Nebraska
    (270, 289),  # North Carolina
    (730, 749),  # Oklahoma
    (290, 299),  # South Carolina
    (370, 385),  # Tennessee
    (750, 799),  # Texas
    (840, 847),  # Utah
    (201, 246),  # Virginia
]

# def is_allowed(zip_code):
#     for start, end in excluded_ranges:
#         if start <= zip_code <= end:
#             return False
#     return True

# def generate_random_zip():
#     while True:
#         zip_code = random.randint(10000, 99999)
#         prefix = int(str(zip_code)[:3])
#         if is_allowed(prefix):
#             return str(zip_code).zfill(5)


def get_random_zip():
    zip_codesCA = [
        "13512"
        "12341",
        "19341",
        "11341",
        "12341",
        "13341",
        "14341",
        "15341",
        "16341",
        "17341",
        "18341",
        "19341",
        "29341",
        "39341",
        "12738",
        "12739",
        "12740",
        "12741",
        "12742",
        "12743",
        "12744",
        "12745",
    ]
    return random.choice(zip_codesCA)




