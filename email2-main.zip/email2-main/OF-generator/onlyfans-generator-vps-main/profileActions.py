
import random
import time
from profileDefs import generate_username
from slenium_functions import random_wait, type_with_delay, wait_for_element
from selenium.common.exceptions import ElementClickInterceptedException
from selenium.webdriver.common.by import By
from selenium.webdriver.common.keys import Keys

def change_username(driver, profile_data, max_attempts=10):
    

    driver.get("https://onlyfans.com/my/settings/profile")
    time.sleep(random.uniform(8, 10))
    for attempt in range(max_attempts):
        username = generate_username()
        profile_data["username"] = username
        print(f"[{attempt+1}] Testuję username: {username}")
        
        input_el = driver.find_element(By.CSS_SELECTOR, 'input[name="username"]')

        # Kliknij pole i usuń stary tekst
        input_el.click()
        time.sleep(random.uniform(0.2, 0.4))

        # Usuwanie istniejącego tekstu
        for _ in range(25):  # zakładamy, że username nie ma więcej niż 25 znaków
            input_el.send_keys(Keys.BACKSPACE)
            time.sleep(random.uniform(0.05, 0.1))

        time.sleep(random.uniform(0.5, 1))
        type_with_delay(input_el, username)

        time.sleep(random.uniform(0.5, 1.2))

        # Znajdź przycisk i sprawdź czy aktywny
        submit_btn = driver.find_element(By.CSS_SELECTOR, 'button[type="submit"]')

        if submit_btn.get_attribute("disabled"):
            print("🔁 Przycisk zablokowany – próbuję z nowym username...")
            continue

        try:
            submit_btn.click()
            print(f"✅ Kliknięto przycisk z username: {username}")
            return  # Sukces
        except ElementClickInterceptedException:
            print("⚠️ Click intercepted – próbuję ponownie z nowym username...")
            continue

    raise Exception("❌ Nie udało się ustawić username po wielu próbach.")



def save_profile(driver):
  driver.find_element(By.CSS_SELECTOR, 'button[type="submit"]').click()


   

# def change_profile(driver):
#     driver.find_element(By.CSS_SELECTOR, 'a[data-name="Profile"]').click()
#     random_wait(4,20) 
#     driver.find_element(By.CSS_SELECTOR, 'a[href="/my/settings/profile"]').click()




   