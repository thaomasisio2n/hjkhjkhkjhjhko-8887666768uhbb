from webdriver_manager.chrome import ChromeDriverManager
from selenium.webdriver.chrome.service import Service
from selenium.webdriver.chrome.options import Options
from selenium import webdriver
import requests
import os

# 🔥 POBIERAMY DRIVER RAZ - Force download of latest version
os.environ['WDM_LOG_LEVEL'] = '0'  # Suppress webdriver-manager logs
CHROME_DRIVER_PATH = ChromeDriverManager(driver_version="133.0.6943.99").install()

def setup_browser(profile_id):
    try:
        response = requests.get("http://local.adspower.net:50325/api/v1/browser/start", params={"user_id": profile_id})
        response.raise_for_status()
        data = response.json()
        if data["code"] == 0:
            chrome_options = Options()
            chrome_options.add_argument("--disable-popup-blocking")
            chrome_options.add_experimental_option("debuggerAddress", data['data']['ws']['selenium'])

            # 🚫 NIE ROBIMY install() za każdym razem!
            driver = webdriver.Chrome(service=Service(CHROME_DRIVER_PATH), options=chrome_options)
            return driver
        else:
            print("❌ Błąd uruchamiania przeglądarki:", data["msg"])
    except requests.RequestException as e:
        print("❌ Błąd żądania:", e)
    except Exception as e:
        print("❌ Nieoczekiwany błąd:", e)
