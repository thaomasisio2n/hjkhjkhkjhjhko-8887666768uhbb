import random
import requests
from config import (
    ADSPOWER_PROFILE_NAME,
    PROXY_TYPE, PROXY_HOST, PROXY_PORT, PROXY_USER, PROXY_PASSWORD, PROXY_SOFT,
    PROXY_ROTATION_URL
)

list = [
    "california",
    "arizona",
    "colorado",
    "connecticut",
]
API_URL = "http://local.adspower.net:50325"


def _build_profile_payload(group_id):
    return {
        "name": ADSPOWER_PROFILE_NAME,
        "group_id": str(group_id),
        "user_proxy_config": {
            "proxy_type": PROXY_TYPE,
            "proxy_host": PROXY_HOST,
            "proxy_port": PROXY_PORT,
            "proxy_user": PROXY_USER,
            "proxy_password": PROXY_PASSWORD,
            "proxy_soft": PROXY_SOFT
        },
        "fingerprint_config": {
            "screen_resolution": "1920_1080",
            "flash": "allow",
            # Kernel selection:
            # - "ua_auto" should smart-match kernel to the UA version below.
            # - If AdsPower respects explicit versions in your build, you can try: {"version": "133", "type": "chrome"}.
            "browser_kernel_config": {
                "version": "ua_auto",
                "type": "chrome",
            },
            "random_ua": {
                "ua_browser": ["chrome"],
                "ua_version": ["133"],
                "ua_system_version": ["Mac OS X 15"]
            },
        }
    }


def createProfile():
    # Zawsze tworzymy profil w domyślnej grupie AdsPower "Ungrouped" (group_id=0).
    data = requests.post(
        f"{API_URL}/api/v1/user/create",
        json=_build_profile_payload("0"),
    ).json()
    if data.get("code") == 0:
        return data["data"]["id"]

    error_msg = data.get("msg", "unknown error")
    error_lower = error_msg.lower()
    print("❌ Błąd tworzenia profilu:", error_msg)

    # Check if this is a profile limit error
    if "limit" in error_lower and any(word in error_lower for word in ["exceeds", "maximum", "reached"]):
        raise Exception(f"ADSPOWER_LIMIT_ERROR: {error_msg}")

    raise Exception(f"Profile creation failed: {error_msg}")

def stopAndDeleteBroswer(profile_id):
    import requests
    import time
    import logging
    logging.basicConfig(level=logging.INFO, format="%(asctime)s - %(levelname)s - %(message)s")
    try:
        print("before Rebooting proxy...")
        # response = requests.get("https://proxy-seller.com/api/proxy/reboot?token=fa6e110e-d3cd-4dc6-bca9-ee6f136e81df")
        # print("after Rebooting proxy... Status:", response.status_code)
        response = requests.get(PROXY_ROTATION_URL)
        print("after Rebooting proxy...")
        # time.sleep(30)
        logging.info("Stopping browser...")
        stop_response = requests.get("http://local.adspower.net:50325/api/v1/browser/stop", params={"user_id": profile_id})
        if stop_response.status_code == 200 and stop_response.json().get("code") == 0:
            logging.info(f"Browser stopped successfully: {stop_response.json()}")
        else:
            logging.error(f"Failed to stop browser: {stop_response.status_code}, {stop_response.text}")
            return  # Nie usuwaj profilu, jeśli nie udało się zamknąć przeglądarki
        time.sleep(7)
        logging.info("Deleting profile...")
        delete_response = requests.post("http://local.adspower.net:50325/api/v1/user/delete", json={"user_ids": [profile_id]})
        if delete_response.status_code == 200 and delete_response.json().get("code") == 0:
            logging.info(f"Profile deleted successfully: {delete_response.json()}")
        else:
            logging.error(f"Failed to delete profile: {delete_response.status_code}, {delete_response.text}")
    except requests.RequestException as e:
        logging.error(f"Error during stop and delete process: {e}")